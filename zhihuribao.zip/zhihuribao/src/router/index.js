import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/components/Home/Home'
import Detail from '@/components/Detail/Detail'
import Comment from '@/components/Comment/Comment'
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Home',
      component: Home
    },
    {
      path:'/detail/:id',
      name:'Detail',
      component:Detail
    },
    {
      path:'/comment/:id',
      name:'Comment',
      component:Comment
    }
  ]
})
