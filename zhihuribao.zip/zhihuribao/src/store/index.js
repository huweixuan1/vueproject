import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)

const store =new Vuex.Store({
    state:{
        isFirstLoad: true, // 是否是第一次进入首页
        Comments:null
    },
    mutations:{
        //修改comments
        setComments(state,val){
            state.Comments=val
        }
    },
    actions:{
        //修改comments
        setComments(context,val){
            context.commit('setComments',val)
        }
    }
    
})
export default store