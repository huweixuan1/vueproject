
import Axios from 'axios'

const newsListUrl = 'api/news/latest'

const getbeforeNewsUrl = 'api/news/before/'
const getnewDetailUrl = 'api/news/'

const getLongCommentUrl = 'api/story/8997528/long-comments'
const getShortCommentUrl = 'api/story/4232852/short-comments'
const getnewsExtraUrl = 'api/story-extra/'

export function getnewsList(){
    return Axios.get(newsListUrl).then(res=>res.data)
}
export function getnewsBefore(date){
    return Axios.get(`${getbeforeNewsUrl}${date}`).then(res=>res.data)
}
export function getnewdetail(date){
    return Axios.get(`${getnewDetailUrl}${date}`).then(res=>res)
}
export function getnewExtra(data){
    return Axios.get(`${getnewsExtraUrl}${data}`).then(res=>res.data)
}
export function getLongComment(id){
    return Axios.get(`api/story/${id}/long-comments`).then(res=>res.data)
}
export function getShortComment(id){
    return Axios.get(`api/story/${id}/short-comments`).then(res=>res.data)
}