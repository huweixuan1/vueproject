<template>
    <div class="detail">
        <header>
            <span @click = 'preHandler'> < </span>
            <span>分享</span>
            <span @click="toComments(id)">评论{{ extraInfo.comments }}</span>
            <span>点赞{{ extraInfo.popularity }}</span>
        </header>
        <div class="headimg">
            <img :src="imgUrl" alt="">
            <span class="title">{{ title }}</span>
            <span class="image_source">{{ image_source }}</span>
        </div>
        <div class="bodybox" v-html="body"></div>
        
    </div>
</template>

<script>


// comments: 70
// long_comments: 3
// popularity: 278
// short_comments: 67

    export default {
        data() {
            return {
                id: null,
                imgUrl:null,
                title:null,
                image_source:null,
                body:null,
                extraInfo:{}
            }
        },
        methods:{
            preHandler(){
                this.$router.go(-1)
            },
            toComments(id){
                this.$router.push({
                    name:'Comment',
                    params:{
                        id
                    }
                })
            }
            
        },
        created(){
            this.$https.getnewdetail(this.$route.params.id).then(res=>{
                //console.log(res)
                this.imgUrl = res.data.image;
                this.title = res.data.title;
                this.image_source = res.data.image_source;
                this.body = res.data.body;
            })
            this.id = this.$route.params.id;
            
            this.$https.getnewExtra(this.$route.params.id).then(res=>{
                this.extraInfo = res;
                this.$store.dispatch('setComments',res.comments)

            })
        }
        
    }
</script>

<style scoped>
@import url('http://news-at.zhihu.com/css/news_qa.auto.css?v=4b3e3');
.detail{
    width: 100%;
    height:100%;
}
header{
    height:50px;
    width:100%;
    position: fixed;
    top:0;
    left: 0;
    background-color: #00aae6;
    color:aliceblue;
    font-size: 14px;
    z-index: 999;
}
header span{
    display: inline-block;
    height:50px;
    padding: 0 10px;
    line-height: 50px;
    margin-left: 10px;
    text-align: center;
}
.headimg{
    height:200px;
    position: absolute;
    overflow-y: hidden;
    width: 100%;
}
.headimg img{
   position: absolute;
   bottom: -105px;
   width: 100%;
}
.headimg .title{
    position:absolute;
    bottom: 20px;
    left:10px;
    color: aliceblue;
    font-size: 16px;
}
.headimg .image_source{
    position: absolute;
    bottom:8px;
    right:10px;
    color:blanchedalmond;
    font-size: 12px;
}
.bodybox .content-wrap .headline .img-place-holder{
    height:0px!important
}



</style>