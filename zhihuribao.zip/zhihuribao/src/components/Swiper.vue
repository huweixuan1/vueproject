<template>
  <div class="swiper">
    <mt-swipe :auto='4000'>
      <mt-swipe-item v-for = '(item) in swiperData' :key="item.id" @click.native='clickHandler(item.id)'>
        <img :src='item.image' :alt="item.title">
        <span class="top-story-title">{{item.title}}</span>
      </mt-swipe-item>
      
    </mt-swipe>
  </div>
</template>

<script>
export default {
  data() {
    return {
      swiperData:[]
      
    }
  },
  methods:{
    clickHandler(id){
      this.$router.push({
        name:'Detail',
        params:{
          id,
        }
      })
    }
  },
  created(){
    this.$https.getnewsList().then(res=>{
      this.swiperData = res.top_stories;
      //console.log(res.top_stories)
    })
  }
};
</script>

<style scoped>
.swiper{
  height: 220px;
  color: #fff;
  font-size: 20px;
}
img{
    position: absolute;
    bottom: -75px;
    width: 100%;
}
.top-story-title{
  position: absolute;
    z-index: 2;
    bottom: 0;
    padding: 30px 20px;
    line-height: 25px;
}
</style>