<template>
  <div class="index">
    <Welcome></Welcome>
    <Sidebar v-show = 'isShow'  @fromSidebartoHideSider = 'hideSidebar'></Sidebar>
    <mt-loadmore
      :bottom-method="loadBottom"
      :topDistance="40"
      ref="loadmore"
      v-infinite-scroll="loadIng"
      infinite-scroll-disabled="isLoad"
      infinite-scroll-distance="0"
      infinite-scroll-immediate-check="1===1"
    >
      <header>
        
        <i class="iconfont icon-ai-kind" @click="showSidebar"></i>
        <span class="hot-news">首页</span>
        
        <i class="iconfont icon-liebiao-dian"></i>
        <i class="iconfont icon-tixing"></i>
      </header>
      <Swiper></Swiper>
      <NewsList ref="newsList"></NewsList>
    </mt-loadmore>
  </div>
</template>

<script>
import Welcome from "../Welcome";
import Swiper from "../Swiper";
import NewsList from "../NewsList";
import Sidebar from "../Sidebar";
export default {
  data() {
    return {
     
      isLoad: true,
      isShow:false
    };
  },
  methods: {
    loadBottom() {
      this.$refs.newsList.$emit("refresh");
      this.$refs.loadmore.onBottomLoaded();
      this.isLoad = false;
    },
    loadIng() {
      this.$refs.newsList.$emit("refresh");
      //console.log(111)
    },
    hideSidebar(msg){
      console.log(msg);
      this.isShow = false;
    },
    showSidebar(){
      this.isShow = true;
    }
  },
  components: {
    Welcome,
    Swiper,
    NewsList,
    Sidebar
  },
  created() {}
};
</script>

<style scoped>
header {
  position: fixed;
  top: 0;
  width: 100%;
  height: 50px;
  z-index: 2;
  font-size: 20px;
  color: #fff;
  line-height: 50px;
  background: #00aae6;
}
header i{
  display: inline-block;
  font-size: 20px;
  
  margin:0 16px;
  float:right;
}
header i:nth-child(1),header span{
  float:left
}
header span{
  margin-left: 16px;
}

</style>