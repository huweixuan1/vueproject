<template>
    <div class="comments">
        <header>
            <i class="iconfont icon-i-back" @click="pre"></i>
            <span>{{this.$store.state.Comments}}条点评</span>
            <i class="iconfont icon-shuxie"></i>
        </header>
        <div class="box">
            <ul class="long_comment" v-show='!longcomments.length==0'>
                <p>{{ longcomments.length }}条长评论</p>
                <li v-for='(item) in longcomments' :key="item.id">
                    <div class="headimg">
                        <div>
                        <img :src="item.avatar" alt="">
                        </div>
                    </div>
                    <div class="rightside">
                        <div class="author">{{ item.author }}</div>
                        <div class="content">{{ item.content}}</div>
                        <div class="date">{{ item.time }}</div>
                    </div>
                </li>
            </ul>
             <ul class="short_coment">
                 <p>{{ shortcomments.length }}条短评</p>
                 <li v-for='(item) in shortcomments' :key="item.id">
                    <div class="headimg">
                        <div>
                        <img :src="item.avatar" alt="">
                        </div>
                    </div>
                    <div class="rightside">
                        <div class="author">{{ item.author }}</div>
                        <div class="content">{{ item.content}}</div>
                        <div class="date">{{ item.time }}</div>
                    </div>
                </li>
             </ul>
        </div>
    </div>
</template>

<script>

// author: "go___go"
// avatar: "http://pic3.zhimg.com/v2-1ae5f682bba916af97aaaddbf193a0f6_im.jpg"
// content: "好吧，那么“孝”的本质又是什么？我的理解是“服从记忆”。大到国家小到家庭都可以是这样。所以在上古时期，社会发展非常缓慢，一代代总结出的经验教训具体反应在团体的权威上，发展出“孝”道，这是很好的制度。但现如今，科学技术的发展，已经颠覆了原有的社会进化的进程，呈跨越发展，所以“孝”就不能那么绝对了"
// id: 33380294
// likes: 9
// time: 1568104248
    export default {
        data() {
            return {
                longcomments:[],
                shortcomments:[]
                
            }
        },
        methods:{
            pre(){
                this.$router.go(-1)
            }

        },
        created(){
            let id = this.$route.params.id
            //获取长评论
            this.$https.getLongComment(id).then(res=>{
                console.log(res.comments);
                this.longcomments = res.comments;
            })
            //获取短评论
            this.$https.getShortComment(id).then(res=>{
                console.log(res.comments)
                this.shortcomments = res.comments
            })
        }
        
    }
</script>

<style scoped>
header{
    height:50px;
    background-color: #00aae6;
    color: white;
    line-height:50px;
    font-size: 16px;
}
header i{
    float:right;
    font-size:20px;
    margin: 0px 10px;
    font-weight: bold;
}
header i:nth-child(1),header span{
    float: left;
}
.box ul{
    background-color: #fcfcfc;
}
.box ul p{
    height:42px;
    line-height:42px;
    color:#515151;
    border-bottom: 1px solid #e7e7e7;
    padding-left: 15px;
}
.box ul li{
    display: flex;
    flex-direction: row;
}
.box ul li .headimg{
    width: 64px;
}
.box ul li .headimg div{
    width: 30px;
    height:30px;
    margin:12px 0 0 15px;
    border-radius: 50%;
    background-color: #666;
    overflow: hidden;

}
.box ul li .headimg div img{
    width: 100%;
    height:auto;
}
.box ul li .rightside{
    display: flex;
    flex-direction: column;
}
.box ul li .rightside div{
    margin:12px 10px 0 4px;

}
.box ul li{
    border-bottom: 1px solid #e7e7e7;
}



</style>