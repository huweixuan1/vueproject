<template>
    <div class="sidebar">
        <div class="bgc" @click="toHomeHideSidebar"></div>
        <div class="usermenu">
            <header>
                <div class="userInfo">
                    <div class="headImg"></div>
                    <div class="username">Huweixuan</div>
                </div>
                <div class="myshoucang">
                     <i class="iconfont icon-shoucangxing2"></i>
                     <span>我的收藏</span>
                </div>
                
            </header>
            <div class="nav">
                <span>首页</span>

            </div>
        </div>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                msg: '我是sidebar组件，即子组件的值'
            }
        },
        methods:{
            //点击侧边阴影部分触发的事件，子组件传递到父亲组件。
            toHomeHideSidebar(){
                this.$emit('fromSidebartoHideSider',this.msg)
            }
        }
        
    }
</script>

<style scoped>
.sidebar{
    width: 80%;
    height:100%;
}
.sidebar .usermenu{
    width:80%;
    height:100%;
    position: absolute;
    top:0;
    left:0;
    background-color:white; 
    z-index: 99;
}
.sidebar .bgc{
    width: 100%;
    height: 100%;
    position: absolute;
    top:0;
    left:0;
    background-color: rgba(0, 0, 0, 0.2);
    z-index: 89;

}
header{
    height: 100px;
    width: 100%;
    background-color: #00aae6;
    color:white;
}
header .userInfo{
    height: 53px;
    width: 100%;
}
header .userInfo >div{
    float:left;
}
header .userInfo .headImg{
    width: 30px;
    height:30px;
    border-radius: 50%;
    background-color:#ccc;
    margin: 11px 15px 0px 15px; 
}
header .userInfo .username{
    height:53px;
    line-height: 53px;
}
.myshoucang{
    margin:17px 0 0 24px; 
    font-size:12px;
}
.myshoucang i{
    font-size: 12px;
    margin-right: 12px;
}
.nav{
    background-color: #efefef;
}
.nav span{
    height: 46px;
    line-height: 46px;
    margin-left: 24px;
    color:#00aae6;
    font-size: 16px;
    display: inline-block;
}
</style>