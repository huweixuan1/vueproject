<template>
  <div class="newList">
    <div class="new" v-for='(it,i) in news' :key='i'>
      <p class="title" v-if='i==0'>今日新闻</p>
      <p class="title" v-else>{{it.date}}</p>
      <ul>
        <li v-for="(item,index) in it.news " :key="index" @click="goDetail(item.id)">
          <div class="left-title">{{item.title}}</div>
          <div class="right-img">
            <img :src="item.images[0]" alt />
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
// ga_prefix: "091316"
// hint: "猫盟CFCA · 4 分钟阅读"
// id: 9715117
// image_hue: "0x8e6c49"
// images: ["https://pic2.zhimg.com/v2-7a19f6e632e7e59de773fdb503f0c95d.jpg"]
// title: "中国现在还有野生的老虎吗？"
// type: 0
// url: "https://daily.zhihu.com/story/9715117"
export default {
  data() {
    return {
      news: [],
      storiesList: [],
      date:null,
      currentDate:null
    };
  },
  props:['loading'],
  methods:{
    //获取前一天的数据
    loadmoreNews(){
     
      this.$https.getnewsBefore(this.date).then(res=>{
        console.log(res)
        let obj = {
          date:res.date,
          news:res.stories
        }
        this.news.push(obj);
      })
      this.date = String(Number(this.date)-1);
      
    },
    //跳转
    goDetail(id){
      this.$router.push({
        name:'Detail',
        params:{
          id,
        }
      })
    }
  },
  created() {
    this.$https.getnewsList().then(res => {
      
      let obj = {
        date:res.date,
        news:res.stories
      }
      this.news.push(obj);
      //console.log(res);
      this.date = res.date;
      this.currentDate = res.date;
     
      
    });
    this.$on('refresh',(res)=>{
          this.loadmoreNews()
      })
  }
};
</script>

<style scoped>
.newList {
  width: 100%;
  background-color: #f3f3f3;
}
.title {
  height: 43px;
  line-height: 50px;
  font-size: 14px;
  color: #a6a6a4;
  padding: 0 0 0 10px;
}
.newList > .new > ul > li {
  height: 95px;
  
  background: white;
  margin: 0 10px;
  border-radius: 5px;
  display: flex;
  justify-content: space-between;
  margin-top: 8px;
}
.left-title {
  margin-top: 10px;
  height: 100%;
  margin-left: 10px;
  font-size: 16px;
  color:#919191 ;
}
.right-img {
  background: #fff;
  width: 74px;
  height: 74px;
  margin: 10px 10px 0 0;
}
.right-img img {
  width: 74px;
  height: 74px;
  display: inline-block;
}
</style>